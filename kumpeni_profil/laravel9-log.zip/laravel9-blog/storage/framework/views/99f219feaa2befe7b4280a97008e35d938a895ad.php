<?php $__env->startSection('content'); ?>
    <main id="main">

        <!-- ======= Breadcrumbs ======= -->
        <div class="breadcrumbs d-flex align-items-center" style="background-image: url();">
            <div class="container position-relative d-flex flex-column align-items-center" data-aos="fade">

                <h2>Blog Details</h2>
                <ol>
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li>Blog Details</li>
                </ol>

            </div>
        </div><!-- End Breadcrumbs -->

        <!-- ======= Blog Details Section ======= -->
        <section id="blog" class="blog">
            <div class="container" data-aos="fade-up" data-aos-delay="100">

                <div class="row g-5 justify-content-center">

                    <div class="col-lg-12">

                        <article class="blog-details">

                            <div class="post-img text-center mb-3">
                                <img src="<?php echo e($item->image()); ?>" alt="" class="img-fluid">
                            </div>

                            <h2 class="title"><?php echo e($item->title); ?>

                            </h2>

                            <div class="meta-top">
                                <ul>
                                    <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a
                                            href="#"><?php echo e($item->user->name); ?></a></li>
                                    <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a
                                            href="#"><?php echo e($item->created_at->translatedFormat('d F Y')); ?></a></li>
                                    
                                </ul>
                            </div><!-- End meta top -->

                            <div class="content">
                                <?php echo $item->description; ?>


                            </div><!-- End post content -->

                            <div class="meta-bottom">
                                <i class="bi bi-folder"></i>
                                <ul class="cats">
                                    <li><a href="#"><?php echo e($item->category->name); ?></a></li>
                                </ul>

                                <i class="bi bi-tags"></i>
                                <ul class="tags">
                                    <?php $__currentLoopData = $item->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="#"><?php echo e($tag->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div><!-- End meta bottom -->

                        </article><!-- End blog post -->

                    </div>
                </div>

            </div>
        </section><!-- End Blog Details Section -->

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel9-blog/resources/views/frontend/pages/blog/show.blade.php ENDPATH**/ ?>