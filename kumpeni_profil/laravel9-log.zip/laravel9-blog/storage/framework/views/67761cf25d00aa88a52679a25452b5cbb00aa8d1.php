<div>
    <footer class="main-footer">
        <div class="text-center">
            &copy; Copyright  <?php echo e($setting->created_at->translatedFormat('Y') . ' By ' . $setting->author); ?>

        </div>
        <div class="footer-right">

        </div>
      </footer>
</div>
<?php /**PATH /var/www/html/laravel9-blog/resources/views/components/admin/footer.blade.php ENDPATH**/ ?>