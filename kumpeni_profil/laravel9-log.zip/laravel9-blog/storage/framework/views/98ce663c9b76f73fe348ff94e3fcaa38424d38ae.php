<meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title><?php echo e($title ?? 'Dashboard'); ?></title>

    <!-- General CSS Files -->
   <link rel="stylesheet" href="<?php echo e(asset('assets/bs/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/fontawesome-free/css/all.min.css')); ?>">

    <!-- CSS Libraries -->

    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/components.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
<?php /**PATH /var/www/html/laravel9-blog/resources/views/admin/layouts/partials/head.blade.php ENDPATH**/ ?>