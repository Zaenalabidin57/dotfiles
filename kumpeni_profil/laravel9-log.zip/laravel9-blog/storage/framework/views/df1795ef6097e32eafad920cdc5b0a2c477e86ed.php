<div>
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e($setting->site_name); ?></a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e($alias); ?></a>
        </div>
        <ul class="sidebar-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Dashboard')): ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>"><i class="fas fa-fire"></i>
                        <span>Dashboard</span></a>
                </li>
            <?php endif; ?>
            <li class="menu-header">Artikel</li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Kategori View')): ?>
                <li>
                    <a class="nav-link" href="<?php echo e(route('admin.post-categories.index')); ?>"><i class="fas fa-list-alt"></i>
                        <span>Kategori</span></a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Tag View')): ?>
                <li>
                    <a class="nav-link" href="<?php echo e(route('admin.post-tags.index')); ?>"><i class="fas fa-tags"></i>
                        <span>Tag</span></a>
                </li>
            <?php endif; ?>
            <li class="nav-item dropdown">
                <a href="#" class="nav-link has-dropdown"><i class="fas fa-fw fa-newspaper"></i>
                    <span>Artikel</span></a>
                <ul class="dropdown-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Artikel Create')): ?>
                        <li><a href="<?php echo e(route('admin.posts.create')); ?>">Tambah Data</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Artikel View')): ?>
                        <li><a href="<?php echo e(route('admin.posts.index')); ?>">Lihat Data</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <li class="menu-header">MASTER</li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('User View')): ?>
                <li>
                    <a class="nav-link" href="<?php echo e(route('admin.users.index')); ?>"><i class="fas fa-users"></i>
                        <span>User</span></a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Filemanager View')): ?>
                <li>
                    <a class="nav-link" target="_blank" href="<?php echo e(url('admin/filemanager')); ?>"><i class="fas fa-folder"></i>
                        <span>File Manager</span></a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Role View')): ?>
                <li>
                    <a class="nav-link" href="<?php echo e(route('admin.roles.index')); ?>"><i class="fas fa-folder"></i>
                        <span>Role</span></a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Permission View')): ?>
                <li>
                    <a class="nav-link" href="<?php echo e(route('admin.permissions.index')); ?>"><i class="fas fa-folder"></i>
                        <span>Hak Akses</span></a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Setting View')): ?>
                <li>
                    <a class="nav-link" href="<?php echo e(route('admin.settings.index')); ?>"><i class="fas fa-cog"></i>
                        <span>Pengaturan Web</span></a>
                </li>
            <?php endif; ?>
        </ul>

    </aside>
</div>
<?php /**PATH /var/www/html/laravel9-blog/resources/views/components/admin/sidebar.blade.php ENDPATH**/ ?>