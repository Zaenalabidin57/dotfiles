<?php if(session('success')): ?>
    <script>
        Swal.fire({
            position: 'center',
            icon: 'success',
            text: '<?php echo e(session('success')); ?>',
            showConfirmButton: true,
            timer: 1500
        })
    </script>
<?php elseif(session('error')): ?>
    <script>
        Swal.fire({
            position: 'center',
            icon: 'error',
            title: '<?php echo e(session('error')); ?>',
            showConfirmButton: true,
            timer: 1500
        })
    </script>
<?php endif; ?>
<?php /**PATH /var/www/html/laravel9-blog/resources/views/admin/layouts/partials/sweetalert.blade.php ENDPATH**/ ?>