<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>Login &mdash; Stisla</title>

  <!-- General CSS Files -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/components.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
</head>

<body>
  <div id="app">
    <?php echo $__env->yieldContent('content'); ?>
  </div>

<!-- General JS Scripts -->
<script src="<?php echo e(asset('assets/js/jquery-3.6.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bs/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.nicescroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/moment.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/stisla.js')); ?>/"></script>

<!-- JS Libraies -->

<!-- Template JS File -->
<script src="<?php echo e(asset('assets/js/scripts.js')); ?>/"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>/"></script>
  <script src="<?php echo e(asset('assets/sweetalert2/sweetalert2.min.js')); ?>"></script>
  <?php echo $__env->make('admin.layouts.partials.sweetalert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Page Specific JS File -->
</body>
</html>
<?php /**PATH /var/www/html/laravel9-blog/resources/views/auth/app.blade.php ENDPATH**/ ?>