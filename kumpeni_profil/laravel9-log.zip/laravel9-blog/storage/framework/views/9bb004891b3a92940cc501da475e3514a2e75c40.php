<!-- General JS Scripts -->
<script src="<?php echo e(asset('assets/js/jquery-3.6.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bs/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.nicescroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/moment.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/stisla.js')); ?>"></script>

<!-- JS Libraies -->

<!-- Template JS File -->
<script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>

<!-- Page Specific JS File -->
<?php /**PATH /var/www/html/laravel9-blog/resources/views/admin/layouts/partials/scripts.blade.php ENDPATH**/ ?>