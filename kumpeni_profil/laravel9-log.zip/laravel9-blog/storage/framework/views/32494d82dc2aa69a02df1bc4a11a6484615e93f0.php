<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('admin.layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div id="app">
        <div class="main-wrapper">
            <div class="navbar-bg"></div>
            <?php if (isset($component)) { $__componentOriginal16922a32012e445d83def1b667bd8c380818a472 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Navbar::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Admin.Navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Admin\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16922a32012e445d83def1b667bd8c380818a472)): ?>
<?php $component = $__componentOriginal16922a32012e445d83def1b667bd8c380818a472; ?>
<?php unset($__componentOriginal16922a32012e445d83def1b667bd8c380818a472); ?>
<?php endif; ?>
            <div class="main-sidebar">
                <?php if (isset($component)) { $__componentOriginalf876cca3a28f659cd5d542fa68eb46dbaafc0d1d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Sidebar::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Admin.Sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Admin\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf876cca3a28f659cd5d542fa68eb46dbaafc0d1d)): ?>
<?php $component = $__componentOriginalf876cca3a28f659cd5d542fa68eb46dbaafc0d1d; ?>
<?php unset($__componentOriginalf876cca3a28f659cd5d542fa68eb46dbaafc0d1d); ?>
<?php endif; ?>
            </div>

            <!-- Main Content -->
            <div class="main-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <?php if (isset($component)) { $__componentOriginal273b99c895545dc613f61f0747b5dd769beb60e4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Footer::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Admin.Footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Admin\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal273b99c895545dc613f61f0747b5dd769beb60e4)): ?>
<?php $component = $__componentOriginal273b99c895545dc613f61f0747b5dd769beb60e4; ?>
<?php unset($__componentOriginal273b99c895545dc613f61f0747b5dd769beb60e4); ?>
<?php endif; ?>
        </div>
    </div>

    <?php echo $__env->make('admin.layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /var/www/html/laravel9-blog/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>