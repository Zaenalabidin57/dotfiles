<div>
    <a href="" >
        <div class="card mb-5 post-card">
            <img src="<?php echo e($image ?? 'o'); ?>" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-text">
                <?php echo e($title ?? 'o'); ?>

              </h5>
            </div>
        </div>
    </a>
</div>
<?php /**PATH /var/www/html/laravel9-blog/resources/views/components/frontend/card-post.blade.php ENDPATH**/ ?>