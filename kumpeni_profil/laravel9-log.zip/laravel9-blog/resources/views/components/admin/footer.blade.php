<div>
    <footer class="main-footer">
        <div class="text-center">
            &copy; Copyright  {{ $setting->created_at->translatedFormat('Y') . ' By ' . $setting->author }}
        </div>
        <div class="footer-right">

        </div>
      </footer>
</div>
