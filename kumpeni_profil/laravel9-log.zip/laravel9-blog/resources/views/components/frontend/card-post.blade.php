<div>
    <a href="" >
        <div class="card mb-5 post-card">
            <img src="{{ $image ?? 'o' }}" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-text">
                {{ $title ?? 'o' }}
              </h5>
            </div>
        </div>
    </a>
</div>
