#!/bin/bash
sudo cp -R ./WindozeXP /usr/share/plymouth/themes/
sudo plymouth-set-default-theme -R WindozeXP
