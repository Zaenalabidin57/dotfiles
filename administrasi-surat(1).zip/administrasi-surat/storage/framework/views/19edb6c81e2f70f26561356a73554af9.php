<?php $__env->startPush('scripts'); ?>
    <?php if(session('success')): ?>
        <script>
            $(function() {
                toastr.success('<?php echo e(session('success')); ?>', 'Berhasil!')
            })
        </script>
    <?php elseif(session('error')): ?>
        <script>
            $(function() {
                toastr.error('<?php echo e(session('error')); ?>', 'Gagal!')
            })
        </script>
    <?php endif; ?>
    <script>
        $(function() {
            $('body').on('click', '.btnDelete', function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        let action = $(this).data('action');
                        $('#formDelete').attr('action', action);
                        $('#formDelete').submit();
                    }
                })
            })
        })
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /var/www/html/administrasi-surat/resources/views/components/toast.blade.php ENDPATH**/ ?>