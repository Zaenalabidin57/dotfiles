<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-3">Surat Keluar</h4>
                    <a href="<?php echo e(route('surat-keluar.create')); ?>" class="btn my-2 mb-3 btn-sm py-2 btn-primary">Buat
                        Surat Keluar</a>
                    <div class="table-responsive">
                        <table class="table dtTable nowrap table-hover">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Jenis</th>
                                    <th>Nomor Surat</th>
                                    <th>Perihal</th>
                                    <th>Tanggal</th>
                                    <th>Isi Singkat</th>
                                    <th>Deadline</th>
                                    <th>File</th>
                                    <th>Asal Surat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->disposisi_id ? 'Internal' : 'External'); ?></td>
                                        <td><?php echo e($item->disposisi_id ? $item->disposisi->surat_masuk->nomor_surat : $item->nomor_surat); ?>

                                        </td>
                                        <td><?php echo e($item->disposisi_id ? $item->disposisi->surat_masuk->perihal : $item->perihal); ?>

                                        </td>
                                        <td><?php echo e($item->disposisi_id ? $item->disposisi->surat_masuk->tanggal : $item->tanggal); ?>

                                        </td>
                                        <td><?php echo e($item->disposisi_id ? $item->disposisi->surat_masuk->isi : $item->isi); ?>

                                        </td>
                                        <td><?php echo e($item->disposisi_id ? $item->disposisi->surat_masuk->deadline : $item->deadline); ?>

                                        </td>
                                        <td>
                                            <a href="<?php echo e($item->disposisi_id ? $item->disposisi->surat_masuk->file() : $item->file()); ?>"
                                                target="_blank" class="btn btn-sm btn-secondary">Lihat</a>
                                        </td>
                                        <td><?php echo $item->disposisi_id ? $item->disposisi->surat_masuk->mahasiswaDetail() : $item->asal_surat; ?></td>
                                        <td>
                                            <?php if($item->disposisi_id == null): ?>
                                                <a href="<?php echo e(route('surat-keluar.edit', $item->id)); ?>"
                                                    class="btn btn-sm py-2 btn-info">Edit</a>
                                                <form action="javascript:void(0)" method="post" class="d-inline"
                                                    id="formDelete">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button class="btn btnDelete btn-sm py-2 btn-danger"
                                                        data-action="<?php echo e(route('surat-keluar.destroy', $item->id)); ?>">Hapus</button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php if (isset($component)) { $__componentOriginale217948d0aa10885800ec2994f6a95b1 = $component; } ?>
<?php $component = App\View\Components\Datatable::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Datatable::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale217948d0aa10885800ec2994f6a95b1)): ?>
<?php $component = $__componentOriginale217948d0aa10885800ec2994f6a95b1; ?>
<?php unset($__componentOriginale217948d0aa10885800ec2994f6a95b1); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/administrasi-surat/resources/views/pages/surat-keluar/index.blade.php ENDPATH**/ ?>