<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-3">Surat Masuk</h4>
                    <div class="table-responsive">
                        <table class="table dtTable nowrap table-hover">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Nomor Surat</th>
                                    <th>Perihal</th>
                                    <th>Tanggal</th>
                                    <th>Isi Singkat</th>
                                    <th>Deadline</th>
                                    <th>File</th>
                                    <th>Penandatanganan</th>
                                    <th>Status</th>
                                    <th>Mahasiswa</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->nomor_surat); ?></td>
                                        <td><?php echo e($item->perihal); ?></td>
                                        <td><?php echo e($item->tanggal); ?></td>
                                        <td><?php echo e($item->isi); ?></td>
                                        <td><?php echo e($item->deadline); ?></td>
                                        <td>
                                            <a href="<?php echo e($item->file()); ?>" target="_blank"
                                                class="btn btn-sm btn-secondary">Lihat</a>
                                        </td>
                                        <td><?php echo e($item->penandatanganan()); ?></td>
                                        <td><?php echo e($item->status()); ?></td>
                                        <td><?php echo $item->mahasiswaDetail(); ?></td>
                                        <td>
                                            <a class="btn btn-info btn-sm"
                                                href="<?php echo e(route('disposisi.index', [
                                                    'id' => $item->id,
                                                ])); ?>">Disposisi</a>
                                            <?php if($item->penandatangan_surat == 0): ?>
                                                <a class="btn btn-info btn-sm"
                                                    href="<?php echo e(route('surat-masuk.update-ttd', [
                                                        'id' => $item->id,
                                                    ])); ?>">Tanda
                                                    Tangan Sekarang</a>
                                            <?php endif; ?>
                                            <div class="dropdown d-inline">
                                                <a class="btn btn-sm btn-secondary dropdown-toggle" href="#"
                                                    role="button" data-toggle="dropdown" aria-expanded="false">
                                                    Ubah Status
                                                </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('surat-masuk.update-status', [
                                                            'status' => 0,
                                                            'id' => $item->id,
                                                        ])); ?>">Belum
                                                        Ditanggapi</a>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('surat-masuk.update-status', [
                                                            'status' => 1,
                                                            'id' => $item->id,
                                                        ])); ?>">Diterima
                                                    </a>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('surat-masuk.update-status', [
                                                            'status' => 2,
                                                            'id' => $item->id,
                                                        ])); ?>">Diproses</a>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('surat-masuk.update-status', [
                                                            'status' => 3,
                                                            'id' => $item->id,
                                                        ])); ?>">Ditolak</a>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('surat-masuk.update-status', [
                                                            'status' => 4,
                                                            'id' => $item->id,
                                                        ])); ?>">Selesai</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php if (isset($component)) { $__componentOriginale217948d0aa10885800ec2994f6a95b1 = $component; } ?>
<?php $component = App\View\Components\Datatable::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Datatable::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale217948d0aa10885800ec2994f6a95b1)): ?>
<?php $component = $__componentOriginale217948d0aa10885800ec2994f6a95b1; ?>
<?php unset($__componentOriginale217948d0aa10885800ec2994f6a95b1); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/administrasi-surat/resources/views/pages/surat-masuk/index.blade.php ENDPATH**/ ?>