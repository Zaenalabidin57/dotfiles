<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table.js')); ?>"></script>
    <script>
        $(function() {
            $('.dtTable').DataTable();
        })
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /var/www/html/administrasi-surat/resources/views/components/datatable.blade.php ENDPATH**/ ?>