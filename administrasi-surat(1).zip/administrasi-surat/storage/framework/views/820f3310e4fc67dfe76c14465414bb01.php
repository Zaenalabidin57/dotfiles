<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- base:css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/vendors/typicons.font/font/typicons.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/vertical-layout-light/style.css">
    <!-- endinject -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets')); ?>/images/favicon.png" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js']); ?>
</head>

<body>

    <?php echo $__env->yieldContent('content'); ?>
    <!-- container-scroller -->
    <!-- base:js -->
    <script src="<?php echo e(asset('assets')); ?>/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- inject:js -->
    <script src="<?php echo e(asset('assets')); ?>/js/off-canvas.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/hoverable-collapse.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/template.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/settings.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/todolist.js"></script>
    <!-- endinject -->
</body>

</html>
<?php /**PATH /var/www/html/administrasi-surat/resources/views/auth/app.blade.php ENDPATH**/ ?>