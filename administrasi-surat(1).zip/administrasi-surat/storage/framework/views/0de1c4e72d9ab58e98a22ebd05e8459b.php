<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <div class="d-flex sidebar-profile">
                <div class="sidebar-profile-image">
                    <img src="<?php echo e(asset('assets')); ?>/images/faces/face29.png" alt="image">
                    <span class="sidebar-status-indicator"></span>
                </div>
                <div class="sidebar-profile-name">
                    <p class="sidebar-name">
                        <?php echo e(auth()->user()->name); ?>

                    </p>
                    <p class="sidebar-designation">
                        Active
                    </p>
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                <i class="typcn typcn-device-desktop menu-icon"></i>
                <span class="menu-title">Dashboard </span>
            </a>
        </li>
        
        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('jabatan.index')); ?>">
                    <i class="typcn typcn-th-large menu-icon"></i>
                    <span class="menu-title">Jabatan </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('program-studi.index')); ?>">
                    <i class="typcn typcn-th-large menu-icon"></i>
                    <span class="menu-title">Program Studi </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('kategori.index')); ?>">
                    <i class="typcn typcn-tags menu-icon"></i>
                    <span class="menu-title">Kategori </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('surat-masuk.index')); ?>">
                    <i class="typcn typcn-tags menu-icon"></i>
                    <span class="menu-title">Surat Masuk </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('surat-keluar.index')); ?>">
                    <i class="typcn typcn-tags menu-icon"></i>
                    <span class="menu-title">Surat Keluar </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('mahasiswa.index')); ?>">
                    <i class="typcn typcn-group-outline menu-icon"></i>
                    <span class="menu-title">Mahasiswa </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('karyawan.index')); ?>">
                    <i class="typcn typcn-group-outline menu-icon"></i>
                    <span class="menu-title">Karyawan </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                    <i class="typcn typcn-group menu-icon"></i>
                    <span class="menu-title">User </span>
                </a>
            </li>
        <?php endif; ?>
        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'mahasiswa')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('permohonan-surat.create')); ?>">
                    <i class="typcn typcn-group menu-icon"></i>
                    <span class="menu-title">Permohonan Surat </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('permohonan-surat.riwayat')); ?>">
                    <i class="typcn typcn-group menu-icon"></i>
                    <span class="menu-title">Riwayat Permohonan </span>
                </a>
            </li>
        <?php endif; ?>
</nav>
<?php /**PATH /var/www/html/administrasi-surat/resources/views/components/sidebar.blade.php ENDPATH**/ ?>