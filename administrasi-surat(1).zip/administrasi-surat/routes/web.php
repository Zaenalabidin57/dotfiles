<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DisposisiController;
use App\Http\Controllers\JabatanController;
use App\Http\Controllers\KaryawanController;
use App\Http\Controllers\KategoriController;
use App\Http\Controllers\MahasiswaController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\PermohonanSuratController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProgramStudiController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\SuratKeluarController;
use App\Http\Controllers\SuratMasukController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Auth::routes();

// admin
Route::middleware('auth')->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/profile', [ProfileController::class, 'index'])->name('profile.index');
    Route::post('/profile', [ProfileController::class, 'update'])->name('profile.update');

    Route::middleware('role:admin')->group(function () {
        Route::resource('users', UserController::class);
        Route::resource('kategori', KategoriController::class)->except('show');
        Route::resource('jabatan', JabatanController::class)->except('show');
        Route::resource('program-studi', ProgramStudiController::class)->except('show');
        Route::resource('mahasiswa', MahasiswaController::class)->except('show');
        Route::resource('karyawan', KaryawanController::class)->except('show');

        Route::get('surat-masuk', [SuratMasukController::class, 'index'])->name('surat-masuk.index');
        Route::get('surat-masuk/update-status', [SuratMasukController::class, 'update_status'])->name('surat-masuk.update-status');
        Route::get('surat-masuk/update-ttd', [SuratMasukController::class, 'update_ttd'])->name('surat-masuk.update-ttd');
        Route::resource('disposisi', DisposisiController::class)->except('show');

        Route::resource('surat-keluar', SuratKeluarController::class)->except('show');
    });

    Route::middleware('role:mahasiswa')->group(function () {
        Route::get('surat/riwayat', [SuratMasukController::class, 'riwayat'])->name('permohonan-surat.riwayat');
        Route::get('surat/permohonan', [SuratMasukController::class, 'create'])->name('permohonan-surat.create');
        Route::post('surat/permohonan', [SuratMasukController::class, 'store'])->name('permohonan-surat.store');
    });
});
