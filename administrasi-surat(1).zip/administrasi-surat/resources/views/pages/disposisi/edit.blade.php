@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-5">Edit Disposisi</h4>
                    <form action="{{ route('disposisi.update', $item->id) }}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('patch')
                        <div class='form-group mb-3'>
                            <label for='' class='mb-2'>Diteruskan Kepada</label>
                            <input type='text' name='' id=''
                                class='form-control @error('') is-invalid @enderror'
                                value=' {{ $item->karyawan->nama . ' - ' . $item->karyawan->jabatan->nama }}' disabled>
                            @error('')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group'>
                            <label for='jenis'>Jenis</label>
                            <select name='jenis' id='jenis' class='form-control @error('jenis') is-invalid @enderror'>
                                <option value='' selected disabled>Pilih Jenis</option>
                                <option @selected($item->jenis === 'Penting') value="Penting">Penting</option>
                                <option @selected($item->jenis === 'Sangat Penting') value="Sangat Penting">Sangat Penting</option>
                                <option @selected($item->jenis === 'Biasa') value="Biasa">Biasa</option>
                                <option @selected($item->jenis === 'Cepat') value="Cepat">Cepat</option>
                                <option @selected($item->jenis === 'Urgent') value="Urgent">Urgent</option>
                                <option @selected($item->jenis === 'Lainnya') value="Lainnya">Lainnya</option>
                            </select>
                            @error('jenis')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group mb-3'>
                            <label for='catatan' class='mb-2'>Catatan</label>
                            <textarea name='catatan' id='catatan' cols='30' rows='3'
                                class='form-control @error('catatan') is-invalid @enderror'>{{ $item->catatan ?? old('catatan') }}</textarea>
                            @error('catatan')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group text-right">
                            <a href="{{ route('disposisi.index', [
                                'id' => $item->surat_masuk_id,
                            ]) }}"
                                class="btn btn-warning">Batal</a>
                            <button class="btn btn-primary">Update Disposisi</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
