@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-5">Tambah Disposisi</h4>
                    <form
                        action="{{ route('disposisi.store', [
                            'id' => $surat_masuk->id,
                        ]) }}"
                        method="post" enctype="multipart/form-data">
                        @csrf
                        <div class='form-group'>
                            <label for='karyawan_id'>Diteruskan Kepada</label>
                            <select name='karyawan_id' id='karyawan_id'
                                class='form-control @error('karyawan_id') is-invalid @enderror'>
                                <option value='' selected disabled>Pilih Karyawan</option>
                                @foreach ($data_karyawan as $karyawan)
                                    <option @selected($karyawan->id == old('karyawan_id')) value='{{ $karyawan->id }}'>
                                        {{ $karyawan->nama . ' - ' . $karyawan->jabatan->nama }}
                                    </option>
                                @endforeach
                            </select>
                            @error('karyawan_id')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group'>
                            <label for='jenis'>Jenis</label>
                            <select name='jenis' id='jenis' class='form-control @error('jenis') is-invalid @enderror'>
                                <option value='' selected disabled>Pilih Jenis</option>
                                <option value="Penting">Penting</option>
                                <option value="Sangat Penting">Sangat Penting</option>
                                <option value="Biasa">Biasa</option>
                                <option value="Cepat">Cepat</option>
                                <option value="Urgent">Urgent</option>
                                <option value="Lainnya">Lainnya</option>
                            </select>
                            @error('jenis')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group mb-3'>
                            <label for='catatan' class='mb-2'>Catatan</label>
                            <textarea name='catatan' id='catatan' cols='30' rows='3'
                                class='form-control @error('catatan') is-invalid @enderror'>{{ old('catatan') }}</textarea>
                            @error('catatan')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group text-right">
                            <a href="{{ route('disposisi.index', [
                                'id' => $surat_masuk->id,
                            ]) }}"
                                class="btn btn-warning">Batal</a>
                            <button class="btn btn-primary">Tambah Disposisi</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
