@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-3">Riwayat Permohonan</h4>
                    <div class="table-responsive">
                        <table class="table dtTable table-hover">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Nomor Surat</th>
                                    <th>Perihal</th>
                                    <th>Tanggal</th>
                                    <th>Isi Singkat</th>
                                    <th>Deadline</th>
                                    <th>File</th>
                                    <th>Penandatanganan</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($items as $item)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $item->nomor_surat }}</td>
                                        <td>{{ $item->perihal }}</td>
                                        <td>{{ $item->tanggal }}</td>
                                        <td>{{ $item->isi }}</td>
                                        <td>{{ $item->deadline }}</td>
                                        <td>
                                            <a href="{{ $item->file() }}" target="_blank"
                                                class="btn btn-sm btn-secondary">Lihat</a>
                                        </td>
                                        <td>{{ $item->penandatanganan() }}</td>
                                        <td>{{ $item->status() }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
<x-Datatable />
