@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-3">Surat Keluar</h4>
                    <a href="{{ route('surat-keluar.create') }}" class="btn my-2 mb-3 btn-sm py-2 btn-primary">Buat
                        Surat Keluar</a>
                    <div class="table-responsive">
                        <table class="table dtTable nowrap table-hover">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Jenis</th>
                                    <th>Nomor Surat</th>
                                    <th>Perihal</th>
                                    <th>Tanggal</th>
                                    <th>Isi Singkat</th>
                                    <th>Deadline</th>
                                    <th>File</th>
                                    <th>Asal Surat</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($items as $item)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $item->disposisi_id ? 'Internal' : 'External' }}</td>
                                        <td>{{ $item->disposisi_id ? $item->disposisi->surat_masuk->nomor_surat : $item->nomor_surat }}
                                        </td>
                                        <td>{{ $item->disposisi_id ? $item->disposisi->surat_masuk->perihal : $item->perihal }}
                                        </td>
                                        <td>{{ $item->disposisi_id ? $item->disposisi->surat_masuk->tanggal : $item->tanggal }}
                                        </td>
                                        <td>{{ $item->disposisi_id ? $item->disposisi->surat_masuk->isi : $item->isi }}
                                        </td>
                                        <td>{{ $item->disposisi_id ? $item->disposisi->surat_masuk->deadline : $item->deadline }}
                                        </td>
                                        <td>
                                            <a href="{{ $item->disposisi_id ? $item->disposisi->surat_masuk->file() : $item->file() }}"
                                                target="_blank" class="btn btn-sm btn-secondary">Lihat</a>
                                        </td>
                                        <td>{!! $item->disposisi_id ? $item->disposisi->surat_masuk->mahasiswaDetail() : $item->asal_surat !!}</td>
                                        <td>
                                            @if ($item->disposisi_id == null)
                                                <a href="{{ route('surat-keluar.edit', $item->id) }}"
                                                    class="btn btn-sm py-2 btn-info">Edit</a>
                                                <form action="javascript:void(0)" method="post" class="d-inline"
                                                    id="formDelete">
                                                    @csrf
                                                    @method('delete')
                                                    <button class="btn btnDelete btn-sm py-2 btn-danger"
                                                        data-action="{{ route('surat-keluar.destroy', $item->id) }}">Hapus</button>
                                                </form>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
<x-Datatable />
