@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-3">Surat Masuk</h4>
                    <div class="table-responsive">
                        <table class="table dtTable nowrap table-hover">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Nomor Surat</th>
                                    <th>Perihal</th>
                                    <th>Tanggal</th>
                                    <th>Isi Singkat</th>
                                    <th>Deadline</th>
                                    <th>File</th>
                                    <th>Penandatanganan</th>
                                    <th>Status</th>
                                    <th>Mahasiswa</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($items as $item)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $item->nomor_surat }}</td>
                                        <td>{{ $item->perihal }}</td>
                                        <td>{{ $item->tanggal }}</td>
                                        <td>{{ $item->isi }}</td>
                                        <td>{{ $item->deadline }}</td>
                                        <td>
                                            <a href="{{ $item->file() }}" target="_blank"
                                                class="btn btn-sm btn-secondary">Lihat</a>
                                        </td>
                                        <td>{{ $item->penandatanganan() }}</td>
                                        <td>{{ $item->status() }}</td>
                                        <td>{!! $item->mahasiswaDetail() !!}</td>
                                        <td>
                                            <a class="btn btn-info btn-sm"
                                                href="{{ route('disposisi.index', [
                                                    'id' => $item->id,
                                                ]) }}">Disposisi</a>
                                            @if ($item->penandatangan_surat == 0)
                                                <a class="btn btn-info btn-sm"
                                                    href="{{ route('surat-masuk.update-ttd', [
                                                        'id' => $item->id,
                                                    ]) }}">Tanda
                                                    Tangan Sekarang</a>
                                            @endif
                                            <div class="dropdown d-inline">
                                                <a class="btn btn-sm btn-secondary dropdown-toggle" href="#"
                                                    role="button" data-toggle="dropdown" aria-expanded="false">
                                                    Ubah Status
                                                </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item"
                                                        href="{{ route('surat-masuk.update-status', [
                                                            'status' => 0,
                                                            'id' => $item->id,
                                                        ]) }}">Belum
                                                        Ditanggapi</a>
                                                    <a class="dropdown-item"
                                                        href="{{ route('surat-masuk.update-status', [
                                                            'status' => 1,
                                                            'id' => $item->id,
                                                        ]) }}">Diterima
                                                    </a>
                                                    <a class="dropdown-item"
                                                        href="{{ route('surat-masuk.update-status', [
                                                            'status' => 2,
                                                            'id' => $item->id,
                                                        ]) }}">Diproses</a>
                                                    <a class="dropdown-item"
                                                        href="{{ route('surat-masuk.update-status', [
                                                            'status' => 3,
                                                            'id' => $item->id,
                                                        ]) }}">Ditolak</a>
                                                    <a class="dropdown-item"
                                                        href="{{ route('surat-masuk.update-status', [
                                                            'status' => 4,
                                                            'id' => $item->id,
                                                        ]) }}">Selesai</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
<x-Datatable />
