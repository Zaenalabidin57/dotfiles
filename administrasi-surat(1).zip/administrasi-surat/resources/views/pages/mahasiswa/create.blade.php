@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-5">Tambah Mahasiswa</h4>
                    <form action="{{ route('mahasiswa.store') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class='form-group mb-3'>
                            <label for='nama' class='mb-2'>Nama</label>
                            <input type='text' name='nama' class='form-control @error('nama') is-invalid @enderror'
                                value='{{ old('nama') }}'>
                            @error('nama')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group mb-3'>
                            <label for='nim' class='mb-2'>NIM</label>
                            <input type='text' name='nim' id='nim'
                                class='form-control @error('nim') is-invalid @enderror' value='{{ old('nim') }}'>
                            @error('nim')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group'>
                            <label for='program_studi_id'>Program Studi</label>
                            <select name='program_studi_id' id='program_studi_id'
                                class='form-control @error('program_studi_id') is-invalid @enderror'>
                                <option value='' selected disabled>Pilih Program Studi</option>
                                @foreach ($data_program_studi as $program_studi)
                                    <option @selected($program_studi->id == old('program_studi_id')) value='{{ $program_studi->id }}'>
                                        {{ $program_studi->nama }}
                                    </option>
                                @endforeach
                            </select>
                            @error('program_studi_id')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group'>
                            <label for='jenis_kelamin'>Jenis kelamin</label>
                            <select name='jenis_kelamin' id='jenis_kelamin'
                                class='form-control @error('jenis_kelamin') is-invalid @enderror'>
                                <option value='' selected disabled>Pilih Jenis kelamin</option>
                                <option @selected(old('jenis_kelamin') === 'Laki-laki') value="Laki-laki">Laki-laki</option>
                                <option @selected(old('jenis_kelamin') === 'Perempuan') value="Perempuan">Perempuan</option>
                            </select>
                            @error('jenis_kelamin')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group mb-3'>
                            <label for='nomor_telepon' class='mb-2'>Nomor HP</label>
                            <input type='text' name='nomor_telepon' id='nomor_telepon'
                                class='form-control @error('nomor_telepon') is-invalid @enderror'
                                value='{{ old('nomor_telepon') }}'>
                            @error('nomor_telepon')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group mb-3'>
                            <label for='email' class='mb-2'>Email</label>
                            <input type='text' name='email' id='email'
                                class='form-control @error('email') is-invalid @enderror' value='{{ old('email') }}'>
                            @error('email')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group mb-3'>
                            <label for='password' class='mb-2'>Password</label>
                            <input type='password' name='password' id='password'
                                class='form-control @error('password') is-invalid @enderror' value='{{ old('password') }}'>
                            @error('password')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group text-right">
                            <a href="{{ route('mahasiswa.index') }}" class="btn btn-warning">Batal</a>
                            <button class="btn btn-primary">Tambah Mahasiswa</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
