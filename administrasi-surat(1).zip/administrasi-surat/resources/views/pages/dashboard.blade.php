@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-sm-6">
            <h1 class="mb-0 font-weight-bold">Dashboard</h1>
        </div>
    </div>
@endsection
