@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-5">Edit Karyawan</h4>
                    <form action="{{ route('karyawan.update', $item->id) }}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('patch')
                        <div class='form-group mb-3'>
                            <label for='nama' class='mb-2'>Nama</label>
                            <input type='text' name='nama' class='form-control @error('nama') is-invalid @enderror'
                                value='{{ $item->nama ?? old('nama') }}'>
                            @error('nama')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group mb-3'>
                            <label for='nip' class='mb-2'>NIP</label>
                            <input type='text' name='nip' id='nip'
                                class='form-control @error('nip') is-invalid @enderror'
                                value='{{ $item->nip ?? old('nip') }}'>
                            @error('nip')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group'>
                            <label for='jabatan_id'>Jabatan</label>
                            <select name='jabatan_id' id='jabatan_id'
                                class='form-control @error('jabatan_id') is-invalid @enderror'>
                                <option value='' selected disabled>Pilih Jabatan</option>
                                @foreach ($data_jabatan as $jabatan)
                                    <option @selected($jabatan->id == $item->jabatan_id) value='{{ $jabatan->id }}'>
                                        {{ $jabatan->nama }}
                                    </option>
                                @endforeach
                            </select>
                            @error('jabatan_id')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group'>
                            <label for='jenis_kelamin'>Jenis kelamin</label>
                            <select name='jenis_kelamin' id='jenis_kelamin'
                                class='form-control @error('jenis_kelamin') is-invalid @enderror'>
                                <option value='' selected disabled>Pilih Jenis kelamin</option>
                                <option @selected($item->jenis_kelamin === 'Laki-laki') value="Laki-laki">Laki-laki</option>
                                <option @selected($item->jenis_kelamin === 'Perempuan') value="Perempuan">Perempuan</option>
                            </select>
                            @error('jenis_kelamin')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class='form-group mb-3'>
                            <label for='nomor_telepon' class='mb-2'>Nomor HP</label>
                            <input type='text' name='nomor_telepon' id='nomor_telepon'
                                class='form-control @error('nomor_telepon') is-invalid @enderror'
                                value='{{ $item->nomor_telepon ?? old('nomor_telepon') }}'>
                            @error('nomor_telepon')
                                <div class='invalid-feedback'>
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group text-right">
                            <a href="{{ route('karyawan.index') }}" class="btn btn-warning">Batal</a>
                            <button class="btn btn-primary">Update Karyawan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
