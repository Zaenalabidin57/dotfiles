<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="#"
                target="_blank">Dev</a>
            2024</span>
        <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Free <a href="#"
                target="_blank">Bootstrap dashboard
            </a>templates from Dev</span>
    </div>
</footer>
