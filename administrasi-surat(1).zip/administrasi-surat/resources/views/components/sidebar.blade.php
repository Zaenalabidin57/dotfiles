<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <div class="d-flex sidebar-profile">
                <div class="sidebar-profile-image">
                    <img src="{{ asset('assets') }}/images/faces/face29.png" alt="image">
                    <span class="sidebar-status-indicator"></span>
                </div>
                <div class="sidebar-profile-name">
                    <p class="sidebar-name">
                        {{ auth()->user()->name }}
                    </p>
                    <p class="sidebar-designation">
                        Active
                    </p>
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="{{ route('dashboard') }}">
                <i class="typcn typcn-device-desktop menu-icon"></i>
                <span class="menu-title">Dashboard </span>
            </a>
        </li>
        {{-- admin --}}
        @role('admin')
            <li class="nav-item">
                <a class="nav-link" href="{{ route('jabatan.index') }}">
                    <i class="typcn typcn-th-large menu-icon"></i>
                    <span class="menu-title">Jabatan </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('program-studi.index') }}">
                    <i class="typcn typcn-th-large menu-icon"></i>
                    <span class="menu-title">Program Studi </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('kategori.index') }}">
                    <i class="typcn typcn-tags menu-icon"></i>
                    <span class="menu-title">Kategori </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('surat-masuk.index') }}">
                    <i class="typcn typcn-tags menu-icon"></i>
                    <span class="menu-title">Surat Masuk </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('surat-keluar.index') }}">
                    <i class="typcn typcn-tags menu-icon"></i>
                    <span class="menu-title">Surat Keluar </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('mahasiswa.index') }}">
                    <i class="typcn typcn-group-outline menu-icon"></i>
                    <span class="menu-title">Mahasiswa </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('karyawan.index') }}">
                    <i class="typcn typcn-group-outline menu-icon"></i>
                    <span class="menu-title">Karyawan </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('users.index') }}">
                    <i class="typcn typcn-group menu-icon"></i>
                    <span class="menu-title">User </span>
                </a>
            </li>
        @endrole
        @role('mahasiswa')
            <li class="nav-item">
                <a class="nav-link" href="{{ route('permohonan-surat.create') }}">
                    <i class="typcn typcn-group menu-icon"></i>
                    <span class="menu-title">Permohonan Surat </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('permohonan-surat.riwayat') }}">
                    <i class="typcn typcn-group menu-icon"></i>
                    <span class="menu-title">Riwayat Permohonan </span>
                </a>
            </li>
        @endrole
</nav>
