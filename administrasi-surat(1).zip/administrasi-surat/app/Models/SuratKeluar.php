<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SuratKeluar extends Model
{
    use HasFactory;
    protected $table  = 'surat_keluar';
    protected $guarded = ['id'];

    public function scopeInternal($val)
    {
        return $val->whereNotNull('disposisi_id');
    }

    public function file()
    {
        return asset('storage/' . $this->file);
    }

    public function disposisi()
    {
        return $this->belongsTo(Disposisi::class, 'disposisi_id', 'id');
    }

    public static function getNewCode()
    {
        $latest = SuratKeluar::latest()->first();
        if (!$latest) {
            $nomor_surat = '001' . '/' . Carbon::now()->format('Y');
        } else {
            $afterSK = \Str::after($latest->nomor_surat, 'SK/');
            $nomor = \Str::before($afterSK, '/');
            $kode_tahun = '/' . Carbon::now()->format('Y');
            $nomor_surat = str_pad($nomor + 1, 3, '0', STR_PAD_LEFT) . $kode_tahun;
        }
        $nomor_baru = 'SK/' . $nomor_surat;
        return $nomor_baru;
    }
}
