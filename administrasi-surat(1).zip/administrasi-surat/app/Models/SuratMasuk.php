<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SuratMasuk extends Model
{
    use HasFactory;
    protected $table = 'surat_masuk';
    protected $guarded = ['id'];

    public function penandatanganan()
    {
        if ($this->penandatangan_surat == 0)
            return 'Belum Ditandatangan';
        else
            return 'Sudah Ditandatangan';
    }

    public function file()
    {
        return asset('storage/' . $this->file);
    }
    public function status()
    {
        if ($this->status == 0)
            return 'Belum Ditanggapi';
        elseif ($this->status == 1)
            return 'Diterima';
        elseif ($this->status == 2)
            return 'Diproses';
        elseif ($this->status == 3)
            return 'Ditolak';
        elseif ($this->status == 4)
            return 'Selesai';
    }

    public function mahasiswa()
    {
        return $this->belongsTo(Mahasiswa::class, 'mahasiswa_id');
    }

    public function mahasiswaDetail()
    {
        return $this->mahasiswa->nama . ' - ' . $this->mahasiswa->nim . ' <br>' . $this->mahasiswa->program_studi->nama;
    }

    public static function getNewCode($kategori_id)
    {
        $kategori = Kategori::findOrFail($kategori_id);
        $latest = SuratMasuk::latest()->first();
        if (!$latest) {
            $nomor_surat = '001' . '/' . $kategori->kode . '/' . Carbon::now()->format('Y');
        } else {
            $afterSM = \Str::after($latest->nomor_surat, 'SM/');
            $nomor = \Str::before($afterSM, '/');
            $kode_tahun = '/' . $kategori->kode . '/' . Carbon::now()->format('Y');
            $nomor_surat = str_pad($nomor + 1, 3, '0', STR_PAD_LEFT) . $kode_tahun;
        }
        $nomor_baru = 'SM/' . $nomor_surat;
        return $nomor_baru;
    }
}
