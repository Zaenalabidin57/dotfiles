<?php

namespace App\Http\Controllers;

use App\Models\Jabatan;
use App\Models\Karyawan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class KaryawanController extends Controller
{
    public function index()
    {
        $items = Karyawan::orderBy('nama', 'ASC')->get();
        return view('pages.karyawan.index', [
            'title' => 'karyawan',
            'items' => $items
        ]);
    }

    public function create()
    {
        $data_jabatan = Jabatan::orderBy('nama', 'ASC')->get();
        return view('pages.karyawan.create', [
            'title' => 'Tambah item',
            'data_jabatan' => $data_jabatan
        ]);
    }

    public function store()
    {
        request()->validate([
            'nama' => ['required'],
            'nip' => ['required', 'unique:karyawan,nip'],
            'jabatan_id' => ['required'],
            'jenis_kelamin' => ['required'],
            'nomor_telepon' => ['required']
        ]);

        DB::beginTransaction();
        try {
            $data = request()->all();
            Karyawan::create($data);

            DB::commit();
            return redirect()->route('karyawan.index')->with('success', 'karyawan berhasil ditambahkan.');
        } catch (\Throwable $th) {
            DB::rollBack();
            // throw $th;
            return redirect()->back()->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $item = Karyawan::findOrFail($id);
        $data_jabatan = Jabatan::orderBy('nama', 'ASC')->get();
        return view('pages.karyawan.edit', [
            'title' => 'Edit karyawan',
            'item' => $item,
            'data_jabatan' => $data_jabatan
        ]);
    }

    public function update($id)
    {
        $item = Karyawan::findOrFail($id);
        request()->validate([
            'nama' => ['required'],
            'nip' => ['required', Rule::unique('karyawan')->ignore($id)],
            'jabatan_id' => ['required'],
            'jenis_kelamin' => ['required'],
            'nomor_telepon' => ['required']
        ]);

        DB::beginTransaction();
        try {
            $item = Karyawan::findOrFail($id);
            $data = request()->all();
            $item->update($data);

            DB::commit();
            return redirect()->route('karyawan.index')->with('success', 'karyawan berhasil diupdate.');
        } catch (\Throwable $th) {
            DB::rollBack();
            // throw $th;
            return redirect()->back()->with('error', $th->getMessage());
        }
    }

    public function destroy($id)
    {

        DB::beginTransaction();
        try {
            $item = Karyawan::findOrFail($id);
            $item->delete();
            DB::commit();
            return redirect()->route('karyawan.index')->with('success', 'karyawan berhasil dihapus.');
        } catch (\Throwable $th) {
            DB::rollBack();
            // throw $th;
            return redirect()->back()->with('error', $th->getMessage());
        }
    }
}
