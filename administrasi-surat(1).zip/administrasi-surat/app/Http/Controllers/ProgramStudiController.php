<?php

namespace App\Http\Controllers;

use App\Models\ProgramStudi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class ProgramStudiController extends Controller
{
    public function index()
    {
        $items = ProgramStudi::orderBy('nama', 'ASC')->get();
        return view('pages.program-studi.index', [
            'title' => 'Program Studi',
            'items' => $items
        ]);
    }

    public function create()
    {
        return view('pages.program-studi.create', [
            'title' => 'Tambah item'
        ]);
    }

    public function store()
    {

        request()->validate([
            'nama' => ['required'],
            'kode' => ['required', 'unique:program_studi,kode'],
            'fakultas' => ['required'],
        ]);

        DB::beginTransaction();
        try {
            $data = request()->all();
            ProgramStudi::create($data);

            DB::commit();
            return redirect()->route('program-studi.index')->with('success', 'Program Studi berhasil ditambahkan.');
        } catch (\Throwable $th) {
            DB::rollBack();
            // throw $th;
            return redirect()->back()->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $item = ProgramStudi::findOrFail($id);
        return view('pages.program-studi.edit', [
            'title' => 'Edit Program Studi',
            'item' => $item
        ]);
    }

    public function update($id)
    {
        request()->validate([
            'nama' => ['required'],
            'kode' => ['required', Rule::unique('program_studi')->ignore($id)],
            'fakultas' => ['required'],
        ]);

        DB::beginTransaction();
        try {
            $item = ProgramStudi::findOrFail($id);
            $data = request()->all();
            $item->update($data);

            DB::commit();
            return redirect()->route('program-studi.index')->with('success', 'Program Studi berhasil diupdate.');
        } catch (\Throwable $th) {
            DB::rollBack();
            // throw $th;
            return redirect()->back()->with('error', $th->getMessage());
        }
    }

    public function destroy($id)
    {

        DB::beginTransaction();
        try {
            $item = ProgramStudi::findOrFail($id);
            $item->delete();
            DB::commit();
            return redirect()->route('program-studi.index')->with('success', 'Program Studi berhasil dihapus.');
        } catch (\Throwable $th) {
            DB::rollBack();
            // throw $th;
            return redirect()->back()->with('error', $th->getMessage());
        }
    }
}
