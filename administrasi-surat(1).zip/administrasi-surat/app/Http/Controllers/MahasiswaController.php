<?php

namespace App\Http\Controllers;

use App\Models\Mahasiswa;
use App\Models\ProgramStudi;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class MahasiswaController extends Controller
{
    public function index()
    {
        $items = Mahasiswa::orderBy('nama', 'ASC')->get();
        return view('pages.mahasiswa.index', [
            'title' => 'Mahasiswa',
            'items' => $items
        ]);
    }

    public function create()
    {
        $data_program_studi = ProgramStudi::orderBy('nama', 'ASC')->get();
        return view('pages.mahasiswa.create', [
            'title' => 'Tambah item',
            'data_program_studi' => $data_program_studi
        ]);
    }

    public function store()
    {
        request()->validate([
            'nama' => ['required'],
            'nim' => ['required', 'unique:mahasiswa,nim'],
            'program_studi_id' => ['required'],
            'jenis_kelamin' => ['required'],
            'nomor_telepon' => ['required'],
            'email' => ['required', 'unique:users,email'],
            'password' => ['required', 'min:5'],
        ]);

        DB::beginTransaction();
        try {
            $data_mahasiswa = request()->except(['email', 'password']);
            $user = User::create([
                'name' => request('nama'),
                'email' => request('email'),
                'password' => bcrypt('password')
            ]);

            $user->assignRole('mahasiswa');
            $data_mahasiswa['user_id'] = $user->id;
            Mahasiswa::create($data_mahasiswa);

            DB::commit();
            return redirect()->route('mahasiswa.index')->with('success', 'Mahasiswa berhasil ditambahkan.');
        } catch (\Throwable $th) {
            DB::rollBack();
            // throw $th;
            return redirect()->back()->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $item = Mahasiswa::findOrFail($id);
        $data_program_studi = ProgramStudi::orderBy('nama', 'ASC')->get();
        return view('pages.mahasiswa.edit', [
            'title' => 'Edit Mahasiswa',
            'item' => $item,
            'data_program_studi' => $data_program_studi
        ]);
    }

    public function update($id)
    {
        $item = Mahasiswa::findOrFail($id);
        request()->validate([
            'nama' => ['required'],
            'nim' => ['required', Rule::unique('mahasiswa')->ignore($id)],
            'program_studi_id' => ['required'],
            'jenis_kelamin' => ['required'],
            'nomor_telepon' => ['required'],
            'email' => ['required', Rule::unique('users', 'email')->ignore($item->user->id)],
            'password' => [Rule::when(request('password'), ['min:5'])],
        ]);

        DB::beginTransaction();
        try {
            $item = Mahasiswa::findOrFail($id);
            $data_mahasiswa = request()->except(['email', 'password']);
            $data_user = [
                'name' => request('nama'),
                'email' => request('email')
            ];
            if (request('password')) {
                $data_user['password'] = bcrypt(request('password'));
            }
            $item->user()->update($data_user);
            $item->update($data_mahasiswa);

            DB::commit();
            return redirect()->route('mahasiswa.index')->with('success', 'Mahasiswa berhasil diupdate.');
        } catch (\Throwable $th) {
            DB::rollBack();
            // throw $th;
            return redirect()->back()->with('error', $th->getMessage());
        }
    }

    public function destroy($id)
    {

        DB::beginTransaction();
        try {
            $item = Mahasiswa::findOrFail($id);
            $item->delete();
            DB::commit();
            return redirect()->route('mahasiswa.index')->with('success', 'Mahasiswa berhasil dihapus.');
        } catch (\Throwable $th) {
            DB::rollBack();
            // throw $th;
            return redirect()->back()->with('error', $th->getMessage());
        }
    }
}
