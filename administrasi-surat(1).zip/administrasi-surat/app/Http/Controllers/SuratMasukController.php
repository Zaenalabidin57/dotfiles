<?php

namespace App\Http\Controllers;

use App\Models\Kategori;
use App\Models\SuratMasuk;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SuratMasukController extends Controller
{
    public function index()
    {
        $items = SuratMasuk::latest()->get();
        return view('pages.surat-masuk.index', [
            'title' => 'Surat Masuk',
            'items' => $items
        ]);
    }
    public function riwayat()
    {
        $items = SuratMasuk::where('mahasiswa_id', auth()->user()->mahasiswa->id)->latest()->get();
        return view('pages.surat-masuk.riwayat', [
            'title' => 'Riwayat Surat',
            'items' => $items
        ]);
    }
    public function create()
    {
        $data_kategori = Kategori::orderBy('nama', 'ASC')->get();
        return view('pages.surat-masuk.create', [
            'title' => 'Permohonan Surat',
            'data_kategori' => $data_kategori
        ]);
    }

    public function store()
    {
        request()->validate([
            'perihal' => ['required'],
            'isi' => ['required'],
            'deadline' => ['required'],
            'file' => ['required', 'file', 'max:2048', 'mimes:pdf']
        ]);

        DB::beginTransaction();
        try {
            $data = request()->all();
            $data['nomor_surat'] = SuratMasuk::getNewCode(request('kategori_id'));
            $data['file'] = request()->file('file')->store('surat-masuk', 'public');
            $data['mahasiswa_id'] = auth()->user()->mahasiswa->id;
            $data['tanggal'] = Carbon::now()->format('Y-m-d');
            SuratMasuk::create($data);

            DB::commit();
            return redirect()->back()->with('success', 'Permohonan Surat berhasil dibuat.');
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    public function update_status()
    {
        request()->validate([
            'status' => ['required', 'in:1,2,3,4'],
            'id' => ['required']
        ]);

        $item = SuratMasuk::findOrFail(request('id'));
        $item->update([
            'status' => request('status')
        ]);

        return redirect()->back()->with('success', 'Status Surat berhasil diupate.');
    }

    public function update_ttd()
    {
        request()->validate([
            'id' => ['required']
        ]);

        $item = SuratMasuk::findOrFail(request('id'));
        $item->update([
            'penandatangan_surat' => 1
        ]);

        return redirect()->back()->with('success', 'Surat Masuk berhasil ditanda tangan.');
    }
}
