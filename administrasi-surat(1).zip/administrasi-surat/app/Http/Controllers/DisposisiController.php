<?php

namespace App\Http\Controllers;

use App\Models\Disposisi;
use App\Models\Karyawan;
use App\Models\SuratKeluar;
use App\Models\SuratMasuk;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DisposisiController extends Controller
{
    public function index()
    {
        $items = Disposisi::where('surat_masuk_id', request('id'))->get();
        return view('pages.disposisi.index', [
            'title' => 'Disposisi',
            'items' => $items,
            'id' => request('id')
        ]);
    }

    public function create()
    {
        $surat_masuk = SuratMasuk::where('id', request('id'))->firstOrFail();
        $data_karyawan = Karyawan::orderBy('nama', 'ASC')->get();
        return view('pages.disposisi.create', [
            'title' => 'Tambah item',
            'data_karyawan' => $data_karyawan,
            'surat_masuk' => $surat_masuk
        ]);
    }

    public function store()
    {
        request()->validate([
            'karyawan_id' => ['required'],
        ]);

        DB::beginTransaction();
        try {
            $data = request()->except('id');
            $data['surat_masuk_id'] = request('id');
            $disposisi = Disposisi::create($data);

            // create surat keluar
            SuratKeluar::create([
                'disposisi_id' => $disposisi->id
            ]);

            DB::commit();
            return redirect()->route('disposisi.index', [
                'id' => request('id')
            ])->with('success', 'Disposisi berhasil ditambahkan.');
        } catch (\Throwable $th) {
            DB::rollBack();
            // throw $th;
            return redirect()->back()->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $item = Disposisi::findOrFail($id);
        return view('pages.disposisi.edit', [
            'title' => 'Edit Disposisi',
            'item' => $item
        ]);
    }

    public function update($id)
    {

        DB::beginTransaction();
        try {
            $item = Disposisi::findOrFail($id);
            $data = request()->only(['jenis', 'catatan']);
            $item->update($data);

            DB::commit();
            return redirect()->route('disposisi.index', [
                'id' => $item->surat_masuk_id
            ])->with('success', 'Disposisi berhasil diupdate.');
        } catch (\Throwable $th) {
            DB::rollBack();
            // throw $th;
            return redirect()->back()->with('error', $th->getMessage());
        }
    }

    public function destroy($id)
    {

        DB::beginTransaction();
        try {
            $item = Disposisi::findOrFail($id);
            $surat_masuk_id = $item->surat_masuk_id;
            $item->delete();
            DB::commit();
            return redirect()->route('disposisi.index', [
                'id' => $surat_masuk_id
            ])->with('success', 'Disposisi berhasil dihapus.');
        } catch (\Throwable $th) {
            DB::rollBack();
            // throw $th;
            return redirect()->back()->with('error', $th->getMessage());
        }
    }
}
