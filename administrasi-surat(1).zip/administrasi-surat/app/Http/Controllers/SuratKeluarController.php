<?php

namespace App\Http\Controllers;

use App\Models\SuratKeluar;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SuratKeluarController extends Controller
{
    public function index()
    {
        $items = SuratKeluar::latest()->get();
        return view('pages.surat-keluar.index', [
            'title' => 'Surat Masuk',
            'items' => $items
        ]);
    }
    public function create()
    {
        return view('pages.surat-keluar.create', [
            'title' => 'Surat Keluar'
        ]);
    }

    public function store()
    {
        request()->validate([
            'perihal' => ['required'],
            'isi' => ['required'],
            'deadline' => ['required'],
            'asal_surat' => ['required'],
            'file' => ['required', 'file', 'max:2048', 'mimes:pdf']
        ]);

        DB::beginTransaction();
        try {
            $data = request()->all();
            $data['nomor_surat'] = SuratKeluar::getNewCode();
            $data['file'] = request()->file('file')->store('surat-keluar', 'public');
            SuratKeluar::create($data);

            DB::commit();
            return redirect()->route('surat-keluar.index')->with('success', 'Surat Keluar berhasil dibuat.');
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    public function edit($id)
    {
        $item = SuratKeluar::findOrFail($id);
        return view('pages.surat-keluar.edit', [
            'title' => 'Edit Surat Keluar',
            'item' => $item
        ]);
    }

    public function update($id)
    {
        request()->validate([
            'perihal' => ['required'],
            'isi' => ['required'],
            'deadline' => ['required'],
            'asal_surat' => ['required'],
            'file' => ['file', 'max:2048', 'mimes:pdf']
        ]);

        DB::beginTransaction();
        try {
            $item = SuratKeluar::findOrFail($id);
            $data = request()->all();
            if (request()->file('file'))
                $data['file'] = request()->file('file')->store('surat-keluar', 'public');
            $item->update($data);

            DB::commit();
            return redirect()->route('surat-keluar.index')->with('success', 'Surat Keluar berhasil diupdate.');
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    public function destroy($id)
    {
        SuratKeluar::destroy($id);
        return redirect()->route('surat-keluar.index')->with('success', 'Surat Keluar berhasil dihapus.');
    }
}
